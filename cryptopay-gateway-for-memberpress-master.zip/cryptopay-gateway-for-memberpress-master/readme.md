## Cryptocurrency Payment Gateway Plugin for MemberPress by CryptoPay

### What does this plugin do?

Blockchain and crypto ecosystem is growing day by day. Many people doing business in this sector also establish communities, sell education, and establish platforms. If you have established a platform with MemberPress on WordPress and are looking for a solution to receive crypto payments for MemberPress, you are in the right place.

Because with CryptoPay, you can get the crypto payment gateway for MemberPress, completely commission-free and peer to peer.

### How does it work?

First of all, you must have one of the Lite or Premium versions of CryptoPay. Because this is an integration plugin. Of course, MemberPress must also be installed. After activating CryptoPay, you need to go to the payment area in your MemberPress settings and add CryptoPay as a payment option. 

As you can see in the pictures, you can then start receiving crypto payments directly with MemberPress.

<a href="https://ibb.co/p4tZDd0"><img src="https://i.ibb.co/MPYpT72/Screenshot-1.png" alt="Screenshot-1" border="0"></a>
<a href="https://ibb.co/cbh8MPy"><img src="https://i.ibb.co/pWjKGg1/Screenshot-2.png" alt="Screenshot-2" border="0"></a>
<a href="https://ibb.co/BCJg0Hm"><img src="https://i.ibb.co/rwhZDKg/Screenshot-3.png" alt="Screenshot-3" border="0"></a>